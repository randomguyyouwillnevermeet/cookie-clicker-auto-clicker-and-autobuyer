Game.registerMod("AutoClickerMod", {
  init: function () {
    (function () {
      function Calculator() {
        this.schema = [
          {
            objects: () =>
              Game.UpgradesInStore.filter(
                (e) =>
                  [69].indexOf(e.id) < 0 &&
                  e.canBuy() &&
                  !e.name.toLowerCase().includes("milk")
              ),
            accessors: {
              add: (e) => (e.bought = 1),
              sub: (e) => (e.bought = 0),
              price: (e) => e.basePrice,
            },
          },
          {
            objects: () =>
              Game.ObjectsById.filter(
                (e) => e.locked === 0 && e.getPrice() > 0 && e.id !== 2 // skip Farm
              ),
            accessors: {
              add: (e) => e.amount++,
              sub: (e) => e.amount--,
              price: (e) => e.getPrice(),
            },
          },
        ];
      }

      Calculator.prototype = {
        cps_acc: (b, n, p) => (b * b) * (n - b) / (p * p),
        ecps: () => Game.cookiesPs * (1 - Game.cpsSucked),
        calc_bonus: function (item, listGen, mouseRate) {
          const base = this.ecps() + Game.computedMouseCps * mouseRate;
          return listGen().map((e) => {
            const price = Math.round(item.price(e));
            item.add(e);
            Game.CalculateGains();
            const cps = this.ecps() + Game.computedMouseCps * mouseRate;
            item.sub(e);
            Game.CalculateGains();
            return { obj: e, price, acc: this.cps_acc(base, cps, price) };
          });
        },
        find_best: function (mouseRate) {
          let pool = [];
          for (let s of this.schema)
            pool = pool.concat(this.calc_bonus(s.accessors, s.objects, mouseRate || 0));
          return pool.reduce((m, v) => (m.acc < v.acc ? v : m), pool[0]);
        },
      };

      function Controller() {
        this.calc = new Calculator();
        this.protect = true;
        this.target = { name: undefined, price: -1 };
        this.total = -1;

        const storeTitle = document.getElementById("storeTitle");
        this.statusEl = document.createElement("span");
        this.statusEl.style.fontSize = "12px";
        this.statusEl.style.marginLeft = "8px";
        this.statusEl.style.color = "#ccc";
        storeTitle.appendChild(this.statusEl);

        this.statusInterval = null;

        // setStatus updates the store status text; popup only on demand
        this.setStatus = (text, popup = false) => {
          if (this.statusInterval) {
            clearInterval(this.statusInterval);
            this.statusInterval = null;
          }
          this.statusEl.textContent = text;
          if (popup) Game.Popup(text, Game.windowW / 2, Game.windowH - 100);
        };

        this.showThinking = () => {
          this.setStatus("🧠 Thinking...");
        };

        this.setCountdown = (obj, seconds) => {
          if (this.statusInterval) clearInterval(this.statusInterval);
          let remaining = seconds;

          const type = obj.bought !== undefined ? "Upgrade" : "Building";

          const updateText = () => {
            const msg = `⏳ Saving up for ${type}: ${obj.name} (${remaining.toFixed(1)}s)`;
            this.statusEl.textContent = msg;
            // No popup here to avoid flicker
          };

          updateText();

          this.statusInterval = setInterval(() => {
            remaining -= 0.1;
            if (remaining <= 0) {
              clearInterval(this.statusInterval);
              this.statusInterval = null;
              this.showThinking();
              return;
            }
            updateText();
          }, 100);
        };

        this.actions = {
          timeouts: {},
          guard: { delay: 300, func: this.guard.bind(this) },
          autobuy: { delay: 500, func: this.autobuy.bind(this) },
          main: {
            delay: 100,
            func: () => Game.ClickCookie(),
          },
          frenzy: {
            delay: 100,
            func: () => {
              if (Game.hasBuff("Click Frenzy") || Game.hasBuff("Frenzy")) Game.ClickCookie();
            },
          },
          gold: {
            delay: 1000,
            func: () => Game.shimmers.forEach((s) => s.pop()),
          },
          fortune: {
            delay: 2000,
            func: () => {
              if (Game.TickerEffect?.type === "fortune") Game.tickerL.click();
            },
          },
          status: {
            delay: 0,
            func: this.status.bind(this),
          },
          protect: {
            delay: 0,
            func: this.toggle_protect.bind(this),
          },
        };
        this.toggle_action("guard");
      }

      Controller.prototype = {
        // say pops up in the black box and updates store text
        say: function (msg) {
          Game.Popup(msg, Game.windowW / 2, Game.windowH - 100);
          this.statusEl.textContent = msg;
        },
        guard: function () {
          let t = this.total;
          this.total =
            1000 * (Game.hasBuff("Frenzy") ? 1 : 0) + Game.BuildingsOwned + Game.UpgradesOwned;
          if (
            this.actions.timeouts.buy &&
            (t != this.total ||
              !this.actions.autobuy.id ||
              this.target.price <= Game.cookies - this.calc.ecps())
          )
            this.unqueue_action("buy");
        },
        autobuy: function () {
          if (this.actions.timeouts.buy) return;
          const info = this.calc.find_best(this.actions.main.id ? 1000 / this.actions.main.delay : 0);
          const protect =
            this.protect && Game.Has("Get lucky")
              ? (Game.hasBuff("Frenzy") ? 1 : 7) * Game.cookiesPs * 1200
              : 0;
          const wait = (protect + info.price - Game.cookies) / this.calc.ecps();

          this.target = { name: info.obj.name, price: protect + info.price };

          const doBuy = () => {
            if (info.price <= Game.cookies) {
              let bought = false;
              if (typeof info.obj.buy === "function") {
                bought = info.obj.buy(); // upgrade
              } else if (typeof info.obj === "object" && typeof info.obj.id === "number") {
                Game.ObjectsById[info.obj.id].buy(1); // building
                bought = true;
              }
              if (bought) {
                this.setStatus(`✅ Bought: ${info.obj.name}`, true);
                this.total++;
                setTimeout(() => {
                  this.showThinking();
                  setTimeout(() => this.autobuy(), 1500);
                }, 3000);
              }
            }
          };

          if (wait > 0) {
            this.setCountdown(info.obj, wait);
            this.queue_action("buy", 1000 * (wait + 0.05), doBuy);
          } else {
            this.setStatus(`⌛ Ready to buy: ${info.obj.name}`);
            doBuy();
          }
        },
        toggle_protect: function () {
          this.protect = !this.protect;
          this.say("Protect is now " + (this.protect ? "ON" : "OFF"));
          this.unqueue_action("buy");
        },
        toggle_action: function (name) {
          const a = this.actions[name];
          if (!a) return;
          if (a.delay) {
            a.id = a.id ? clearInterval(a.id) : setInterval(a.func, a.delay);
            this.say(`"${name}" turned ` + (a.id ? "on" : "off"));
          } else a.func();
        },
        unqueue_action: function (name) {
          const t = this.actions.timeouts;
          if (t[name]) {
            clearTimeout(t[name]);
            delete t[name];
          }
        },
        queue_action: function (name, delay, func) {
          this.unqueue_action(name);
          this.actions.timeouts[name] = setTimeout(() => {
            func();
            delete this.actions.timeouts[name];
          }, delay);
        },
        status: function () {
          const out = Object.keys(this.actions)
            .filter((k) => this.actions[k].delay && k !== "guard")
            .map((k) => `${k}: ${this.actions[k].id ? "on" : "off"}`)
            .join(", ");
          this.setStatus("Status: " + out);
        },
      };

      const view = {
        ctrl: new Controller(),
        actions: {
          65: "autobuy", // A
          70: "frenzy", // F
          71: "gold", // G
          77: "main", // M
          78: "fortune", // N
          80: "protect", // P
          83: "status", // S
        },
      };

      document.addEventListener("keydown", (e) => {
        if (view.actions[e.keyCode]) view.ctrl.toggle_action(view.actions[e.keyCode]);
      });

      [65, 70, 71, 77].forEach((k) => {
        view.ctrl.toggle_action(view.actions[k]);
      });
    })();
  },
  save: function () {},
  load: function () {},
});
